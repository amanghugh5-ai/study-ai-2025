## Packages
react-markdown | For rendering AI-generated study content
framer-motion | For smooth transitions and animations
date-fns | Formatting history dates

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
